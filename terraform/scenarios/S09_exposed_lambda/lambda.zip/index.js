exports.handler = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify({ message: "graphshield-s09-lambda" })
  };
};
